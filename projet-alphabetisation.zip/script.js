
// Visualisation 1 : bar chart
const ctxBar = document.getElementById('barChart');
new Chart(ctxBar, {
    type: 'bar',
    data: {
        labels: ['France', 'Maroc', 'Sénégal', 'Inde', 'Canada', 'Brésil'],
        datasets: [{
            label: 'Taux d'alphabétisation (%) - 2023',
            data: [99, 73, 52, 78, 99, 94],
            backgroundColor: 'rgba(54, 162, 235, 0.6)'
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                max: 100
            }
        }
    }
});

// Visualisation 2 : line chart
const ctxLine = document.getElementById('lineChart');
new Chart(ctxLine, {
    type: 'line',
    data: {
        labels: [2000, 2005, 2010, 2015, 2020],
        datasets: [
            {
                label: 'France',
                data: [98, 99, 99, 99, 99],
                borderColor: 'rgba(255, 99, 132, 1)',
                fill: false
            },
            {
                label: 'Maroc',
                data: [52, 60, 67, 71, 73],
                borderColor: 'rgba(255, 206, 86, 1)',
                fill: false
            },
            {
                label: 'Sénégal',
                data: [38, 42, 45, 49, 52],
                borderColor: 'rgba(75, 192, 192, 1)',
                fill: false
            },
            {
                label: 'Inde',
                data: [61, 66, 70, 75, 78],
                borderColor: 'rgba(153, 102, 255, 1)',
                fill: false
            }
        ]
    },
    options: {
        responsive: true
    }
});
