
# Visualisation - Taux d'alphabétisation dans le monde

Ce projet présente deux visualisations interactives sur le taux d’alphabétisation :

1. **Taux par pays (2023)** : graphique en barres comparant France, Maroc, Sénégal, Inde, Canada et Brésil.
2. **Évolution temporelle (2000-2020)** : graphique en lignes pour France, Maroc, Sénégal, Inde.

## Données
Source : Banque Mondiale  
Lien : https://data.worldbank.org/indicator/SE.ADT.LITR.ZS

## Visualisation
Outil utilisé : [Chart.js](https://www.chartjs.org/)

## Déploiement
Le projet peut être affiché en ligne via GitHub Pages.
